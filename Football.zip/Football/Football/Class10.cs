﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Football
{
    public class Game
    {
        public Team Team1 { get; set; }
        public Team Team2 { get; set; }
        public Referee Referee { get; set; }
        public List<AssistantReferee> AssistantReferees { get; set; }
        public List<Goal> Goals { get; set; }

        public string Result
        {
            get
            {
                int team1Goals = Goals.FindAll(goal => goal.Player.Team == Team1).Count;
                int team2Goals = Goals.FindAll(goal => goal.Player.Team == Team2).Count;

                if (team1Goals > team2Goals)
                    return $"{Team1.Coach.Name}'s team won";
                else if (team1Goals < team2Goals)
                    return $"{Team2.Coach.Name}'s team won";
                else
                    return "It's a draw";
            }
        }

        public Team Winner
        {
            get
            {
                int team1Goals = Goals.FindAll(goal => goal.Player.Team == Team1).Count;
                int team2Goals = Goals.FindAll(goal => goal.Player.Team == Team2).Count;

                if (team1Goals > team2Goals)
                    return Team1;
                else if (team1Goals < team2Goals)
                    return Team2;
                else
                    return null;
            }
        }
    }
}
